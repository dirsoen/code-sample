package com.qygly.demo.dto;

/**
 * 演示的控制器的方法的返回值。
 */
public class Result {
    public String info;

    public Result(String info) {
        this.info = info;
    }
}
